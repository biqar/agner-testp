#!/bin/bash
# init64.sh                                            2016-09-25 Agner Fog

# Initialization of files before running test scripts
# Run 64-bit mode only
# (c) Copyright 2016 by Agner Fog. GNU General Public License www.gnu.org/licenses

./init.sh 64
